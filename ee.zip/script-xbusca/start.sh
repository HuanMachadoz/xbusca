#!bin/bash
cyan="\033[0;36m"
while : 
do
echo "${cyan}Iniciando script apis void."
    node index.js
    sleep 1

done