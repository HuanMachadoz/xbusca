// index.js
const express = require("express");
const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const axios = require("axios");
const cheerio = require("cheerio");
const input = require("input");
const fs = require("fs");
const path = require("path");
const config = require("./string/config");

const app = express();
const sessionPath = path.join(__dirname, "database", "session.txt");

// --- Carrega sessão existente ---
let stringSession = "";
if (fs.existsSync(sessionPath)) {
    stringSession = fs.readFileSync(sessionPath, "utf8");
}

const client = new TelegramClient(
    new StringSession(stringSession),
    config.apiId,
    config.apiHash,
    { connectionRetries: 5 }
);

// --- Inicializa Telegram ---
async function startClient() {
    try {
        await client.start({
            phoneNumber: async () => await input.text("Digite seu número: "),
            password: async () => await input.text("Digite sua senha 2FA: "),
            phoneCode: async () => await input.text("Digite o código recebido: "),
            onError: (err) => console.log("Erro Telegram:", err),
        });

        const sessao = client.session.save();
        fs.mkdirSync(path.dirname(sessionPath), { recursive: true });
        fs.writeFileSync(sessionPath, sessao);
        console.log("💾 Sessão salva em", sessionPath);
        console.log("✅ Telegram conectado!");
    } catch (err) {
        console.error("❌ Falha ao iniciar Telegram:", err);
        process.exit(1);
    }
}

// --- Limpa arquivos antigos da pasta tmp ---
function cleanTmpFolder() {
    const tmpDir = path.join(__dirname, "tmp");
    if (!fs.existsSync(tmpDir)) return;

    const now = Date.now();
    const files = fs.readdirSync(tmpDir);
    files.forEach(file => {
        const filePath = path.join(tmpDir, file);
        const stats = fs.statSync(filePath);
        if (now - stats.mtimeMs > 60000) fs.unlinkSync(filePath);
    });
}
setInterval(cleanTmpFolder, 30000);

// --- Espera próxima mensagem do bot ---
async function waitBotMessage(botUsername) {
    const botEntity = await client.getEntity(botUsername);

    return new Promise((resolve) => {
        const handler = (event) => {
            const msg = event.message;
            if (!msg) return;
            client.removeEventHandler(handler);
            resolve(msg);
        };
        client.addEventHandler(handler, new NewMessage({ incoming: true, fromUsers: [botEntity.id] }));
    });
}

// --- Processa mensagem do bot (qualquer foto + texto abaixo) ---
async function processMessage(msg) {
    let fotoBase64 = null;
    let texto = msg.message || "";

    // Checa se há foto ou mídia de imagem
    if (msg.photo || (msg.media && msg.media.photo)) {
        const buffer = await client.downloadMedia(msg.photo || msg.media);
        fotoBase64 = buffer.toString("base64");
    }

    return { fotoBase64, texto };
}

// --- Endpoint /cpf com limpeza do texto ---

app.get("/cpf", (req, res) => {
    const numero = req.query.numero;
    if (!numero) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /cpf
    client.sendMessage(botUsername, { message: `/cpf ${numero}` }).then(() => {

        // 2️⃣ Espera menu com botão
        client.getEntity(botUsername).then(botEntity => {

            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                // Remove handler do menu
                client.removeEventHandler(menuHandler);

                let encontrouBotao = false;

                // 3️⃣ Procura e clica no botão CPF FULL
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (btn.text && btn.text.toUpperCase().includes("CPF FULL")) {
                            encontrouBotao = true;

                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 4️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 5️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document).then(buffer => {
                                        const texto = buffer.toString("utf8");

                                        // 6️⃣ Responde API
                                        return res.json({
                                            cpf: numero,
                                            resultado: texto
                                        });
                                    }).catch(err => {
                                        console.error(err);
                                        res.status(500).json({ error: "Erro ao ler arquivo" });
                                    });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({ incoming: true, fromUsers: [botEntity.id] })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar no botão" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrouBotao) {
                    return res.status(500).json({ error: "Botão CPF FULL não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({ incoming: true, fromUsers: [botEntity.id] })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /cpf" });
    });
});

app.get("/nome", (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.status(400).json({ error: "Informe o nome" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /nome
    client.sendMessage(botUsername, { message: `/nome ${nome}` }).then(() => {

        // 2️⃣ Pega entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                nome,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /nome" });
    });
});

app.get("/telefone", (req, res) => {
    const telefone = req.query.numero;
    if (!telefone) {
        return res.status(400).json({ error: "Informe o telefone" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /telefone
    client.sendMessage(botUsername, {
        message: `/telefone ${telefone}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão TELEFONE X BUSCAS / X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            (
                                btn.text.toUpperCase().includes("TELEFONE X BUSCAS") ||
                                btn.text.toUpperCase().includes("X BUSCAS")
                            )
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                telefone,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar no botão TELEFONE X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão TELEFONE X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /telefone" });
    });
});

app.get("/cnhnc", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /cnhnc
    client.sendMessage(botUsername, {
        message: `/cnhnc ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão CNH NACIONAL X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            (
                                btn.text.toUpperCase().includes("CNH NACIONAL X BUSCAS") ||
                                btn.text.toUpperCase().includes("CNH X BUSCAS") ||
                                btn.text.toUpperCase().includes("X BUSCAS")
                            )
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                cpf,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em CNH NACIONAL X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão CNH NACIONAL X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /cnhnc" });
    });
});

app.get("/pai", (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.status(400).json({ error: "Informe o nome" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /pai com NOME
    client.sendMessage(botUsername, {
        message: `/pai ${nome}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão PAI X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            (
                                btn.text.toUpperCase().includes("PAI X BUSCAS") ||
                                btn.text.toUpperCase().includes("PAI") ||
                                btn.text.toUpperCase().includes("X BUSCAS")
                            )
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                nome,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em PAI X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão PAI X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /pai" });
    });
});

app.get("/mae", (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.status(400).json({ error: "Informe o nome" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /mae
    client.sendMessage(botUsername, {
        message: `/mae ${nome}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão MÃE X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            (
                                btn.text.toUpperCase().includes("MÃE X BUSCAS") ||
                                btn.text.toUpperCase().includes("MAE X BUSCAS") ||
                                btn.text.toUpperCase().includes("MÃE") ||
                                btn.text.toUpperCase().includes("MAE") ||
                                btn.text.toUpperCase().includes("X BUSCAS")
                            )
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                nome,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em MÃE X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão MÃE X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /mae" });
    });
});

app.get("/email", (req, res) => {
    const email = req.query.email;
    if (!email) {
        return res.status(400).json({ error: "Informe o email" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /email
    client.sendMessage(botUsername, {
        message: `/email ${email}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão EMAIL X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            (
                                btn.text.toUpperCase().includes("EMAIL X BUSCAS") ||
                                btn.text.toUpperCase().includes("E-MAIL X BUSCAS") ||
                                btn.text.toUpperCase().includes("EMAIL") ||
                                btn.text.toUpperCase().includes("X BUSCAS")
                            )
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                email,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em EMAIL X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão EMAIL X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /email" });
    });
});

app.get("/scorehistorico", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /scorehistorico
    client.sendMessage(botUsername, {
        message: `/scorehistorico ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão HISTORICO SCORE X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            (
                                btn.text.toUpperCase().includes("HISTORICO SCORE X BUSCAS") ||
                                btn.text.toUpperCase().includes("HISTÓRICO SCORE X BUSCAS") ||
                                btn.text.toUpperCase().includes("SCORE X BUSCAS") ||
                                btn.text.toUpperCase().includes("X BUSCAS")
                            )
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                cpf,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em HISTÓRICO SCORE X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão HISTÓRICO SCORE X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /scorehistorico" });
    });
});

app.get("/cnpj", (req, res) => {
    const cnpj = req.query.cnpj;
    if (!cnpj) {
        return res.status(400).json({ error: "Informe o CNPJ" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /cnpj
    client.sendMessage(botUsername, {
        message: `/cnpj ${cnpj}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura botão CNPJ X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            (
                                btn.text.toUpperCase().includes("CNPJ X BUSCAS") ||
                                btn.text.toUpperCase().includes("X BUSCAS") ||
                                btn.text.toUpperCase().includes("CNPJ")
                            )
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            const texto = buffer.toString("utf8");

                                            return res.json({
                                                cnpj,
                                                resultado: texto
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em CNPJ X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    return res.status(500).json({ error: "Botão CNPJ X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /cnpj" });
    });
});

app.get("/titulo", (req, res) => {
    const nome = req.query.nome;
    if (!nome) {
        return res.status(400).json({ error: "Informe o nome" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /titulo
    client.sendMessage(botUsername, {
        message: `/titulo ${nome}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "TÍTULO X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("TÍTULO X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                nome,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em TÍTULO X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão TÍTULO X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /titulo" });
    });
});

app.get("/rg", (req, res) => {
    const rg = req.query.rg;
    if (!rg) {
        return res.status(400).json({ error: "Informe o RG" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /rg
    client.sendMessage(botUsername, {
        message: `/rg ${rg}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "RG X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("RG X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                rg,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em RG X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão RG X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /rg" });
    });
});

app.get("/nascimento", (req, res) => {
    const nascimento = req.query.nascimento;
    if (!nascimento) {
        return res.status(400).json({ error: "Informe a data de nascimento" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /nascimento
    client.sendMessage(botUsername, {
        message: `/nascimento ${nascimento}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "NASCIMENTO X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("NASCIMENTO X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                nascimento,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em NASCIMENTO X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão NASCIMENTO X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /nascimento" });
    });
});

app.get("/cep", (req, res) => {
    const cep = req.query.cep;
    if (!cep) {
        return res.status(400).json({ error: "Informe o CEP" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /cep
    client.sendMessage(botUsername, {
        message: `/cep ${cep}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "CEP X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("CEP X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cep,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em CEP X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão CEP X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /cep" });
    });
});

app.get("/obito", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /obito
    client.sendMessage(botUsername, {
        message: `/obito ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "ÓBITO X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("ÓBITO X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em ÓBITO X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão ÓBITO X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /obito" });
    });
});

app.get("/bens", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /bens
    client.sendMessage(botUsername, {
        message: `/bens ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "BENS X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("BENS X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em BENS X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão BENS X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /bens" });
    });
});

app.get("/certidoes", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /certidoes
    client.sendMessage(botUsername, {
        message: `/certidoes ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura "CERTIDÕES X BUSCAS" (com tolerância)
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        const text = (btn.text || "").toUpperCase();
                        if (
                            text.includes("CERTID") &&
                            text.includes("X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em CERTIDÕES X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão CERTIDÕES X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /certidoes" });
    });
});

app.get("/vacinas", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /vacinas
    client.sendMessage(botUsername, {
        message: `/vacinas ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "VACINAS X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("VACINAS X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em VACINAS X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão VACINAS X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /vacinas" });
    });
});

app.get("/irpf", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /irpf
    client.sendMessage(botUsername, {
        message: `/irpf ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "IRPF X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("IRPF X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em IRPF X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão IRPF X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /irpf" });
    });
});

app.get("/score", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /score
    client.sendMessage(botUsername, {
        message: `/score ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botões
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "SCORE X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("SCORE X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em SCORE X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão SCORE X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /score" });
    });
});

app.get("/cnhnc", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /cnhnc
    client.sendMessage(botUsername, {
        message: `/cnhnc ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura CNH NACIONAL X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("CNH") &&
                            btn.text.toUpperCase().includes("NACIONAL") &&
                            btn.text.toUpperCase().includes("X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e lê o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(err => {
                                            console.error(err);
                                            res.status(500).json({ error: "Erro ao ler arquivo TXT" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(err => {
                                console.error(err);
                                res.status(500).json({ error: "Erro ao clicar em CNH NACIONAL X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão CNH NACIONAL X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(err => {
            console.error(err);
            res.status(500).json({ error: "Erro ao obter entidade do bot" });
        });

    }).catch(err => {
        console.error(err);
        res.status(500).json({ error: "Erro ao enviar comando /cnhnc" });
    });
});

app.get("/placa", (req, res) => {
    const placa = req.query.placa;
    if (!placa) {
        return res.status(400).json({ error: "Informe a placa" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /placa
    client.sendMessage(botUsername, {
        message: `/placa ${placa}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "PLACA X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("PLACA X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e responde com o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                placa,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo TXT" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em PLACA X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão PLACA X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /placa" });
    });
});

app.get("/renavam", (req, res) => {
    const renavam = req.query.renavam;
    if (!renavam) {
        return res.status(400).json({ error: "Informe o RENAVAM" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /renavam
    client.sendMessage(botUsername, {
        message: `/renavam ${renavam}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "RENAVAM X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("RENAVAM X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e retorna o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                renavam,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo TXT" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em RENAVAM X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão RENAVAM X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /renavam" });
    });
});

app.get("/chassi", (req, res) => {
    const chassi = req.query.chassi;
    if (!chassi) {
        return res.status(400).json({ error: "Informe o chassi" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia comando /chassi
    client.sendMessage(botUsername, {
        message: `/chassi ${chassi}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu com botão
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura SOMENTE "CHASSI X BUSCAS"
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("CHASSI X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera o arquivo TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Baixa e retorna o TXT
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                chassi,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo TXT" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em CHASSI X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão CHASSI X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /chassi" });
    });
});

app.get("/motor", (req, res) => {
    const motor = req.query.motor;
    if (!motor) {
        return res.status(400).json({ error: "Informe o motor" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /motor
    client.sendMessage(botUsername, {
        message: `/motor ${motor}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura MOTOR X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("MOTOR X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Retorna conteúdo
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                motor,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo TXT" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em MOTOR X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão MOTOR X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /motor" });
    });
});

app.get("/registrocnh", (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    // 1️⃣ Envia /registrocnh
    client.sendMessage(botUsername, {
        message: `/registrocnh ${cpf}`
    }).then(() => {

        // 2️⃣ Obtém entidade do bot
        client.getEntity(botUsername).then(botEntity => {

            // 3️⃣ Espera menu
            const menuHandler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                client.removeEventHandler(menuHandler);

                let encontrou = false;

                // 4️⃣ Procura N REGISTRO CNH X BUSCAS
                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("N REGISTRO CNH X BUSCAS")
                        ) {
                            encontrou = true;

                            // 5️⃣ Clica no botão
                            client.invoke(
                                new Api.messages.GetBotCallbackAnswer({
                                    peer: msg.peerId,
                                    msgId: msg.id,
                                    data: btn.data
                                })
                            ).then(() => {

                                // 6️⃣ Espera TXT
                                const docHandler = (event2) => {
                                    const docMsg = event2.message;
                                    if (!docMsg || !docMsg.document) return;

                                    client.removeEventHandler(docHandler);

                                    // 7️⃣ Retorna conteúdo
                                    client.downloadMedia(docMsg.document)
                                        .then(buffer => {
                                            res.json({
                                                cpf,
                                                resultado: buffer.toString("utf8")
                                            });
                                        })
                                        .catch(() => {
                                            res.status(500).json({ error: "Erro ao ler arquivo TXT" });
                                        });
                                };

                                client.addEventHandler(
                                    docHandler,
                                    new NewMessage({
                                        incoming: true,
                                        fromUsers: [botEntity.id]
                                    })
                                );

                            }).catch(() => {
                                res.status(500).json({ error: "Erro ao clicar em N REGISTRO CNH X BUSCAS" });
                            });

                            return;
                        }
                    }
                }

                if (!encontrou) {
                    res.status(500).json({ error: "Botão N REGISTRO CNH X BUSCAS não encontrado" });
                }
            };

            client.addEventHandler(
                menuHandler,
                new NewMessage({
                    incoming: true,
                    fromUsers: [botEntity.id]
                })
            );

        }).catch(() => {
            res.status(500).json({ error: "Erro ao obter bot" });
        });

    }).catch(() => {
        res.status(500).json({ error: "Erro ao enviar comando /registrocnh" });
    });
});

app.get("/foto", async (req, res) => {
    const cpf = req.query.cpf;
    if (!cpf) {
        return res.status(400).json({ error: "Informe o CPF" });
    }

    const botUsername = "@BuscasXBot";

    try {
        // 1️⃣ Envia /foto
        await client.sendMessage(botUsername, {
            message: `/foto ${cpf}`
        });

        const botEntity = await client.getEntity(botUsername);

        // ===============================
        // ETAPA 1 — clicar em NACIONAL
        // ===============================
        const nacionalMsg = await new Promise(resolve => {
            const handler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (btn.text && btn.text.toUpperCase().includes("NACIONAL")) {
                            client.removeEventHandler(handler);
                            resolve({ msg, btn });
                            return;
                        }
                    }
                }
            };

            client.addEventHandler(
                handler,
                new NewMessage({ incoming: true, fromUsers: [botEntity.id] })
            );
        });

        await client.invoke(
            new Api.messages.GetBotCallbackAnswer({
                peer: nacionalMsg.msg.peerId,
                msgId: nacionalMsg.msg.id,
                data: nacionalMsg.btn.data
            })
        );

        // ======================================
        // ETAPA 2 — clicar em FOTO NACIONAL X BUSCAS
        // ======================================
        const fotoBtnMsg = await new Promise(resolve => {
            const handler = (event) => {
                const msg = event.message;
                if (!msg || !msg.replyMarkup) return;

                for (const row of msg.replyMarkup.rows || []) {
                    for (const btn of row.buttons || []) {
                        if (
                            btn.text &&
                            btn.text.toUpperCase().includes("FOTO") &&
                            btn.text.toUpperCase().includes("NACIONAL")
                        ) {
                            client.removeEventHandler(handler);
                            resolve({ msg, btn });
                            return;
                        }
                    }
                }
            };

            client.addEventHandler(
                handler,
                new NewMessage({ incoming: true, fromUsers: [botEntity.id] })
            );
        });

        await client.invoke(
            new Api.messages.GetBotCallbackAnswer({
                peer: fotoBtnMsg.msg.peerId,
                msgId: fotoBtnMsg.msg.id,
                data: fotoBtnMsg.btn.data
            })
        );

        // ======================================
        // ETAPA 3 — capturar 2 fotos + texto
        // ======================================
        const fotos = [];
        let texto = "";

        await new Promise(resolve => {
            const handler = async (event) => {
                const msg = event.message;
                if (!msg) return;

                if (msg.photo && fotos.length < 2) {
                    const buffer = await client.downloadMedia(msg.photo);
                    fotos.push(buffer.toString("base64"));
                }

                if (msg.message) {
                    texto += msg.message + "\n";
                }

                if (fotos.length === 2) {
                    client.removeEventHandler(handler);
                    resolve();
                }
            };

            client.addEventHandler(
                handler,
                new NewMessage({ incoming: true, fromUsers: [botEntity.id] })
            );
        });

        // ===============================
        // RESPOSTA FINAL
        // ===============================
        res.json({
            cpf,
            fotos: {
                foto1_base64: fotos[0],
                foto2_base64: fotos[1]
            },
            texto: texto.trim()
        });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Erro ao processar /foto" });
    }
});

// --- Inicia servidor ---
app.listen(config.port, async () => {
    console.log("⏳ Inicializando Telegram...");
    await startClient();
    console.log(`🚀 API rodando em http://localhost:${config.port}`);
});