module.exports = {
  apiId: 25910732,                     // seu api_id
  apiHash: "8a5981540c4de5c9eb6b1b31dfd57fe7",           // seu api_hash
  botUsername: "@BuscasXBot",   // usuário do bot
  session: "",                       // se já tiver uma session salva pode colar aqui
  port: 3538                   // porta que a API vai rodar
};